package ma.sqli.Decorator;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap.KeySetView;


/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public class Etudiant  extends DecoratorPersonne {
	
	public  HashMap<ProfEncadrant,Boolean>choix;
	/**
	 * 
	 */
	public void   addChoix(LinkedList<ProfEncadrant> prof) {
		for (int i=0;i<3;i++) {
			choix.put(prof.get(i), false);
		}
	}
	public void removeChoix(ProfEncadrant prof) {
		choix.put(prof, false);
	}
	public Etudiant(IPersonne personne) {
		// TODO Auto-generated constructor stub
		super(personne);
		choix = new HashMap<ProfEncadrant,Boolean>();
	}
	
	public void choixProf(ProfEncadrant prof) {
	 	choix.put(prof, true);
	 	prof.addEtudiant(this);
	}
	
	public LinkedList<ProfEncadrant> profNoChoise(){
		LinkedList<ProfEncadrant> liste = new LinkedList<ProfEncadrant>();
		for(ProfEncadrant prof: choix.keySet()) {
			if(choix.get(prof)==false) {
				liste.add(prof);
			}
		}
		return liste;
	}
	public boolean  profTrue(ProfEncadrant prof) {
		return  this.choix.get(prof) ==true;
	}
	
	
	//////////////////////////////-------- les geters et le seters------------/////////////////////////
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Etudiant e = (Etudiant) obj;
		return this.getNom().equals(e.getNom());
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+" *  Les Profs==> "+choix;
	}
	
	
	public void printChoix() {
		for(ProfEncadrant key:choix.keySet()) {
			System.out.println(key.toString());
		}

	}
	
	/**
	 * @return the choix
	 */
	public HashMap<ProfEncadrant, Boolean> getChoix() {
		return choix;
	}
	 
	

}
