package Configuration;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Configuration
 * Date    =====> 28 oct. 2019 
 */
public interface Configuration {
	static int maxChoix  = 3;
	static  int nombre_prof = 5;
	static int supA3  = 1;
	static int InfA3 = 2;
	static int nbrChoixSupAcapacite = 3;
	static int nbrChoixInfAcapacite = 4;

}
