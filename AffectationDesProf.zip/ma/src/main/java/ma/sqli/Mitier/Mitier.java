package ma.sqli.Mitier;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.*;
import Configuration.Configuration;
import ma.sqli.Decorator.*;
import ma.sqli.FactoryPersone.FactoryPersone;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> ma.sqli.Mitier
 * Date    =====> 28 oct. 2019 
 */
public class Mitier  implements IMitier {
		private    LinkedList<Etudiant> etudiants;
		private    LinkedList<ProfEncadrant>profs,liste_manupiler,liste_return,liste_G1,liste_G2;
		//la liste D affectation FInale
		private Map<Etudiant,Date>Affectation;
		//private LinkedList<ProfEncadrant> liste_manupiler ;
		private LinkedList<ProfEncadrant> liste_test = new LinkedList<ProfEncadrant>();
		private FactoryPersone facp;
	///////////////////:	 Constructeur ////////////////
		
		public Mitier() {
			// TODO Auto-generated constructor stub
			etudiants = new LinkedList<Etudiant>(); 
			profs = new LinkedList<ProfEncadrant>();
			Affectation = new HashMap<>();
		    facp = new FactoryPersone();

		}
			//////////////////////////////////////////////////////

		//////////////////Ajouter les Etudiants et les Profs////////////////////////
		
		public boolean addEtudiant(Etudiant e) {
			return this.etudiants.add(e);
		}
		
		public boolean addProf(ProfEncadrant p) {
			return this.profs.add(p);
		}
		public boolean ajoutProf(String nom, String prenom,String univ ,int nombre) {
			ProfEncadrant newProf  = facp.getInstance(nom, prenom, univ, nombre);
			boolean existeProf = existeProfParNom(newProf);
			if(!existeProf) {
				profs.add(newProf);
			}
			return (!existeProf);
		}
		
		
		public boolean ajoutEtudiant(String nom, String prenom) {
			Etudiant newEtudiant = facp.getInstance(nom, prenom);
			boolean existeEtudiant = existeEtudiant(newEtudiant);
			if(!existeEtudiant) {
				etudiants.add(newEtudiant);
			}
			return (!existeEtudiant);
		}
		
		public boolean  addProfs(LinkedList<ProfEncadrant> listeProfs) {
			return this.profs.addAll(listeProfs);
		}
			///////////////////////////////// fin ajout  des etudant et les profs///////////////
	
		
		////////////////////// Le traitement  d affectation de 3 choix pour chaque Etudiant////////////////////////
		public   void ProfAleatoire(){
					LinkedList<ProfEncadrant> list;
		        	list = new LinkedList<ProfEncadrant>();
	         
		        	for(int i=0;i<etudiants.size();i++) {
		                     list = (LinkedList<ProfEncadrant>) selectioné().clone();
			                  this. etudiants.get(i).addChoix(list);
	   
			                      	}							
	                    	}
		
	////////////////////////// selectionne 3 Profs aleatoite /////////////////////////////////	     
		
		public LinkedList<ProfEncadrant> selectioné() {
			
	          int valeur_rand;int max= Configuration.nombre_prof;
	          liste_manupiler = new LinkedList<ProfEncadrant>();	          
	  		  liste_return = new LinkedList<ProfEncadrant>();
	  		  liste_G1 = new LinkedList<ProfEncadrant>();
	  		  liste_G2 = new LinkedList<ProfEncadrant>();
		      liste_manupiler = (LinkedList<ProfEncadrant>)profs.clone();
		      
		      //rassemble le groupe 1 qu on la capacite <=3
		      liste_G1 =(LinkedList<ProfEncadrant>) sousListe(liste_manupiler,2);
		      
		      //rassemble le groupe 2 qu on la capacité>3
		      liste_G2 =(LinkedList<ProfEncadrant>) sousListe(liste_manupiler,1);
		      
				for(int i=0;i<Configuration.maxChoix;i++) {
					if( testCapaciteGroupe( liste_G1)) {			
	                     liste_G1=sousListe(liste_G1, 2);
							valeur_rand = (int)((Math.random()* (liste_G1.size())));
								liste_G1.get(valeur_rand).setFilter_rand();
								liste_return.add(liste_G1.get(valeur_rand));

								liste_G1.remove(valeur_rand);

					}else {
						valeur_rand = (int)((Math.random()* (liste_G2.size())));
						liste_return.add(liste_G2.get(valeur_rand));
						liste_G2.remove(valeur_rand);
					}
		}
				
								     profs = (LinkedList<ProfEncadrant>) liste_manupiler.clone();
				return liste_return;
				
		}
		//////////////////////-------------fin de traitement  d affectation de 3 choix pour chaque Etudiant
		
		/////////////------------recuperer des sous liste---------------- //////////////////////////
		
		public LinkedList<ProfEncadrant> sousListe(LinkedList<ProfEncadrant> profs , int choix){
			LinkedList<ProfEncadrant>liste_return1,liste_return2 ,liste_return3,liste_return4,liste_return;
			liste_return = new LinkedList<ProfEncadrant>();
			liste_return.clear();
			switch(choix) {
			case Configuration.supA3 :
				liste_return1= new LinkedList<ProfEncadrant>();
				  liste_return1 =(LinkedList<ProfEncadrant>) (profs.stream()
					      .filter(x -> x.getNombre_etudiant_s() > 3)
					      .collect(Collectors.toCollection(LinkedList::new)).clone());
				  liste_return=(LinkedList<ProfEncadrant>) liste_return1.clone();
				  break;
				  
			case Configuration.InfA3 :
				liste_return2= new LinkedList<ProfEncadrant>();
				 liste_return2 =(LinkedList<ProfEncadrant>) (profs.stream()
					      .filter(x -> x.getNombre_etudiant_s() <= 3 && testCapaciteProf(x))
					      .collect(Collectors.toCollection(LinkedList::new)).clone());
				 liste_return=(LinkedList<ProfEncadrant>) liste_return2.clone();
				 break;
				 
			case Configuration.nbrChoixInfAcapacite :
				liste_return3 = new LinkedList<ProfEncadrant>();
				liste_return3 = (LinkedList<ProfEncadrant>)(profs.stream()
						.filter(x->x.getEtudiants().size()<x.getNombre_etudiant_s()))
						.collect(Collectors.toCollection(LinkedList::new)).clone();
				liste_return=(LinkedList<ProfEncadrant>) liste_return3.clone();		
				break;
				
			case Configuration.nbrChoixSupAcapacite :
				liste_return4 = new LinkedList<ProfEncadrant>();
				liste_return4 = (LinkedList<ProfEncadrant>)(profs.stream()
						.filter(x->x.getEtudiants().size()>x.getNombre_etudiant_s()))
						.collect(Collectors.toCollection(LinkedList::new)).clone();
				liste_return=(LinkedList<ProfEncadrant>) liste_return4.clone();		
				System.out.println(liste_return4);
				break;
				
			}
			return liste_return;
		}
		
	   ////////////////////////////////////////////////////////////////--------fin recuperation des sous liste.
		
		//////////////////////////////-----Traitement Apres le choix des etudiant --////////////////////
		
		public void CorrectionApresChoix() {
			LinkedList<ProfEncadrant> listeFullPlein = new LinkedList<>();
			LinkedList<ProfEncadrant>listeLessPlein  = new LinkedList<ProfEncadrant>();
			LinkedList<Etudiant> listeAttende = new LinkedList<Etudiant>();
			LinkedList<ProfEncadrant>listeFalse = new LinkedList<ProfEncadrant>();
			listeFullPlein = (LinkedList<ProfEncadrant>) sousListe(profs, 3);
			listeLessPlein = (LinkedList<ProfEncadrant>) sousListe(profs, 4).clone();
			int valeur_rand;
			//Recuperer D une maniere aleatoire les etudaints depuis la listeFullPlein
			for(ProfEncadrant prof : listeFullPlein) {
				while(prof.getEtudiants().size()>prof.getNombre_etudiant_s()) {
					valeur_rand = (int)((Math.random()* (prof.getEtudiants().size())));
	                listeAttende.add(prof.getEtudiants().get(valeur_rand));
	                prof.getEtudiants().get(valeur_rand).removeChoix(prof);
	                prof.getEtudiants().remove(valeur_rand);
	                
			     }
			 }
			//Affectation des etudiants qu on dans la liste d attende
			for(Etudiant etudiant : listeAttende) {
					listeFalse = new LinkedList<ProfEncadrant>();
					listeFalse = etudiant.profNoChoise();
					listeLessPlein = (LinkedList<ProfEncadrant>) sousListe(profs, 4).clone();
					if(existeProf(listeLessPlein, listeFalse.get(0))) {
						etudiant.choixProf(listeFalse.get(0));
						listeFalse.get(0).addEtudiant(etudiant);
					}
					else if(existeProf(listeLessPlein, listeFalse.get(1))) {
						etudiant.choixProf(listeFalse.get(1));	
						listeFalse.get(1).addEtudiant(etudiant);
					}
					else {
						valeur_rand = (int)((Math.random()* (listeLessPlein.size())));
						etudiant.choixProf(listeLessPlein.get(valeur_rand));
						listeLessPlein.get(valeur_rand).addEtudiant(etudiant);
					}
			}
			

		}
		//////////////////////---------tester Les Choix Des etudiant-------//////////////////
		
		public void choixPourChaqueEtudiant() {
			etudiants.get(0).choixProf(profs.get(1));     
			etudiants.get(1).choixProf(profs.get(1));
			etudiants.get(2).choixProf(profs.get(0));
			etudiants.get(3).choixProf(profs.get(4));
			etudiants.get(4).choixProf(profs.get(5));
			etudiants.get(5).choixProf(profs.get(0));
			etudiants.get(6).choixProf(profs.get(0));
			etudiants.get(7).choixProf(profs.get(0));
			etudiants.get(8).choixProf(profs.get(0));

		}
		
		public boolean testerChoix(Etudiant etudiant,ProfEncadrant prof) {
				return  etudiant.profTrue(prof);
		
		}
		
		public boolean  profChoisé(Etudiant   etudiant,ProfEncadrant prof) {
			return (etudiant.getChoix().get(prof)==true);
			
		}
		
		//////////////////////////////////////////////////-------------fin test de choix
		
		//////////////////////--------- function d existance ---------//////////////////////////
		
		public  boolean existeProf(LinkedList<ProfEncadrant> profs ,ProfEncadrant prof) {
			return profs.contains(prof);
		}
		
		public boolean existeProfParNom(ProfEncadrant prof) {
			ProfEncadrant Chekedprof = profs.stream()
					.filter(x->x.equals(prof))
					.findAny()
					.orElse(null);
			return !(Chekedprof==null);
					

		}
		
		public boolean existeEtudiant(Etudiant e) {
			Etudiant chekedEtudiant = etudiants.stream()
					.filter(x->x.equals(e))
					.findAny()
					.orElse(null);
			return !(chekedEtudiant == null);

		}
		
	 public boolean choixDisponible(Etudiant e) {
		 return !(e.getChoix().isEmpty());
	 }
	 

		
		
		
		//////////////////////////////////////////////////////////////////////////////-------------fin Traitement
	 
	 ////////////////////////---Redifinition de clone ---------------////////////////////////
		@Override
		public Object clone() throws CloneNotSupportedException {
			LinkedList<ProfEncadrant> copy = new LinkedList<ProfEncadrant>();
			// TODO Auto-generated method stub
			for(ProfEncadrant prof: this.profs) {
				copy.add(prof);
			}
			return copy;
		}
		////////////////////////////////////////////////////////////////////////////////////
		
		//////////////////////////////////////// les geters et les Seters///////////////////////////
		
		public LinkedList<Etudiant> getEtudiants() {
			return etudiants;
		}
		
		public  LinkedList<ProfEncadrant> getProfs() {
			return profs;
		}
	
		/**
		 * @param profs the profs to set
		 */
		
		public void setProfs(LinkedList<ProfEncadrant> profs) {
			this.profs = profs;
	    	}
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////
		
	//////////-------------- l affichage d affectation de choix--------------///////////////////////////////
		
		public void printEtudiants() {			
	         for(Etudiant e: this.etudiants) {
	        	 System.out.println(e);
	               }

	   	}
		/////////////////////////////////////////////////////////////////////////---------fin test affichage
		
		/////////////////////////////-------tester la capacité du groupe et de prof-----//////////////////////
		
		@Override
		public boolean testCapaciteGroupe(LinkedList<ProfEncadrant> profs) {
			// TODO Auto-generated method stub
			int a=0 ,b=0;
			for(ProfEncadrant prof : profs) {
				a+=prof.getFilter_rand();
				b+=prof.getNombre_etudiant_s();
			}
			return a<b;
		}
		
		@Override
		public boolean testCapaciteProf(ProfEncadrant prof) {
			// TODO Auto-generated method stub
			return prof.getFilter_rand()<prof.getNombre_etudiant_s();
		}
		/////////////////////////////////////////////////////////////////////////////---------- fin test capacité

	
	}


