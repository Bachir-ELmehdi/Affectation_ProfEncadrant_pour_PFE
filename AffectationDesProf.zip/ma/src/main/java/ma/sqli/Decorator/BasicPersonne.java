package ma.sqli.Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public class BasicPersonne implements IPersonne {
	private String nom;
	private  String prenom;
	 /**
	 * 
	 */
	public BasicPersonne(String nom,String prenom) {
		// TODO Auto-generated constructor stub
		this.nom = nom;
		this.prenom = prenom;
		
	}

    public	String  getNom() {
		// TODO Auto-generated method stub
		return nom;
		
	}

	public String getPrenom() {
		// TODO Auto-generated method stub
		return prenom;
		
	}
	
	@Override
	public boolean equals(Object o) {
		BasicPersonne p =( BasicPersonne)o;
		return this.nom.equals(p.nom);
	}
	@Override
	public String toString() {
		return "NOM : "+nom;
				    // " Prenom : "+prenom;        
	}

}
