package ma.sqli.Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public interface IPersonne {
	String  getNom();
	String getPrenom();
	boolean equals(Object o);
	String toString();

}
