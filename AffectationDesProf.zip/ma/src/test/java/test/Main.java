package test;

import org.junit.Assert;

import ma.sqli.FactoryPersone.FactoryPersone;
import ma.sqli.Mitier.Mitier;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> test
 * Date    =====> 16 nov. 2019 
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       Mitier  Gestion  = new Mitier();
			FactoryPersone facp = new FactoryPersone();
			Gestion.ajoutEtudiant("mehdi", "bachir");
			Gestion.ajoutEtudiant("reda", "dhimni");
			Gestion.ajoutEtudiant("annas", "ariss");
			Gestion.ajoutEtudiant("Ayman", "bourhil");
			Gestion.ajoutEtudiant("Hamza ", "sabair");
			Gestion.ajoutEtudiant("Hassna", "belaini");
			Gestion.ajoutEtudiant("Ihsanne", "Lachhab");
			 Gestion.ajoutEtudiant("Amine", "Aouni");
			 Gestion.ajoutEtudiant("simo", "Gnawi");
			 
			 //ajout du Prof
			 
			 
			     Assert.assertEquals(true, Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4));
				Assert.assertEquals(true, Gestion.ajoutProf("haziti", "haziti", "Mohamed5", 2));
				Assert.assertEquals(true, Gestion.ajoutProf("ourdi", "ourdi", "Mohamed5", 3));
				Assert.assertEquals(true, Gestion.ajoutProf("khatabi", "khatabi", "Mohamed5", 5));
				Assert.assertEquals(true, Gestion.ajoutProf("oumari", "oumari", "Mohamed5", 2));
				Assert.assertEquals(true, Gestion.ajoutProf("Benkhalifa", "BenKhalifa", "Mohamed5", 4));
				//System.out.println(Gestion.getProfs());
			       
			       //affectation des profs
		        System.out.println("--------------------------------------");
			       System.out.println("Les Profes");
			       System.out.println("----------------------------------------");
			       System.out.println(Gestion.getProfs());
			        System.out.println("--------------------------------------");
			       System.out.println("Apres L affectation");
			       System.out.println("----------------------------------------");
		     Gestion.ProfAleatoire();
		     
	        Gestion.printEtudiants();
		    System.out.println("--------------------------------------");
	        System.out.println("Apres Le choix des etudiants");		 
	        System.out.println("--------------------------------------");
	        Gestion.choixPourChaqueEtudiant();	
	        Gestion.printEtudiants();

	
		Gestion.CorrectionApresChoix();
        System.out.println("--------------------------------------");
	    System.out.println("Apres la correction des choix des etudiants");		 
	    System.out.println("--------------------------------------");
	    Gestion.printEtudiants();
}

}
