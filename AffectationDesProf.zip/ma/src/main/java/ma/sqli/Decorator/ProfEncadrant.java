package ma.sqli.Decorator;

import java.util.LinkedList;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public class ProfEncadrant  extends DecoratorPersonne{
	private String university;
	private int nombre_etudiant_s;
	private int filter_rand =0;
	private  int count = 1;
	private LinkedList<Etudiant> etudiants;
  //  private boolean selectionné;//ce Champ  pour avois c est ce prof a ete choiser par un etudiant
	/**
	 * @param personne
	 */
	public ProfEncadrant(IPersonne personne,String university,int  nombre_etudiant_s) {
		super(personne);
		this.university = university;
		this.nombre_etudiant_s  = nombre_etudiant_s;
		etudiants = new LinkedList<Etudiant>();

	}
	
	public void addEtudiant(Etudiant etudiant) {
		etudiants.add(etudiant);
	}
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		ProfEncadrant p = (ProfEncadrant) obj;
		return this.getNom().equals(p.getNom());
	}
	/**
	 * @return the nombre_etudiant_s
	 */
	public int getNombre_etudiant_s() {
		return nombre_etudiant_s;
	}
	/**
	 * @return the university
	 */
	public String getUniversity() {
		return university;
	}
	/**
	 * @return the filter_rand
	 */
	public int getFilter_rand() {
		return filter_rand;
	}
	/**
	 * @param filter_rand the filter_rand to set
	 */
	public void setFilter_rand() {
		this.filter_rand =count++;
	}
	/**
	 * @return the count
	 */
	public  int getCount() {
		return count;
	}
	/**
	 * @return the etudiants
	 */
	public LinkedList<Etudiant> getEtudiants() {
		return etudiants;
	}

	

}
