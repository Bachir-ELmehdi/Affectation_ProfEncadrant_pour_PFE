package ma.sqli.Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public abstract class DecoratorPersonne implements IPersonne {
	
	private IPersonne personne;
	
	/**
	 * 
	 */
	public DecoratorPersonne(IPersonne personne) {
		// TODO Auto-generated constructor stub
		this.personne = personne;
	}
	public String getNom() {
		// TODO Auto-generated method stub
		return personne.getNom();
	}
	public String getPrenom() {
		// TODO Auto-generated method stub
		return personne.getPrenom();
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return personne.equals(obj);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return personne.toString();
	}
	
	

}
