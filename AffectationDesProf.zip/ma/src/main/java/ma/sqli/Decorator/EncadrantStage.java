package ma.sqli.Decorator;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> Decorator
 * Date    =====> 28 oct. 2019 
 */
public class EncadrantStage  extends DecoratorPersonne{

	/**
	 * @param personne
	 */
	public EncadrantStage(IPersonne personne) {
		super(personne);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return super.getNom();
	}
	@Override
	public String getPrenom() {
		// TODO Auto-generated method stub
		return super.getPrenom();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}
