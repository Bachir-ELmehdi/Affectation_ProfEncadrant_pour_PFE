package ma.sqli.FactoryPersone;

import ma.sqli.Decorator.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> FactoryPersone
 * Date    =====> 28 oct. 2019 
 */
public interface IFactoryPersonne {
	Etudiant getInstance(String nom,String prenom);
	ProfEncadrant getInstance(String nom,String prenom,String univ,int nombre);
	EncadrantStage getInstance(String nom,String prenom ,int i);

}
