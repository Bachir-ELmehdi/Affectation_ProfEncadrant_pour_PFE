package ma.sqli.Mitier;
import java.util.LinkedList;

import ma.sqli.Decorator.*;
/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> ma.sqli.Mitier
 * Date    =====> 28 oct. 2019 
 */
public interface IMitier {
	
	public LinkedList<ProfEncadrant> selectioné();
	public   void ProfAleatoire();
	public void CorrectionApresChoix();
	public LinkedList<ProfEncadrant> sousListe(LinkedList<ProfEncadrant> profs , int choix);
	public boolean testCapaciteGroupe(LinkedList<ProfEncadrant>profs);
	public boolean testCapaciteProf(ProfEncadrant prof);
	public boolean existeProfParNom(ProfEncadrant prof) ;
	public boolean existeEtudiant(Etudiant e);
	public boolean choixDisponible(Etudiant e);
	public void printEtudiants();
	public void choixPourChaqueEtudiant();
    public 	Object clone() throws CloneNotSupportedException;
	
	

}
