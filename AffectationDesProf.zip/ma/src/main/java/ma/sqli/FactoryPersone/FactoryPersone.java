package ma.sqli.FactoryPersone;

import ma.sqli.Decorator.BasicPersonne;
import ma.sqli.Decorator.EncadrantStage;
import ma.sqli.Decorator.Etudiant;
import ma.sqli.Decorator.ProfEncadrant;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> FactoryPersone
 * Date    =====> 28 oct. 2019 
 */
public class FactoryPersone implements IFactoryPersonne{

	public Etudiant getInstance(String nom,String prenom) {
		// TODO Auto-generated method stub
		
		return new Etudiant(new BasicPersonne(nom,prenom));
	}

	public ProfEncadrant getInstance(String nom,String prenom,String univ,int nombre) {
		// TODO Auto-generated method stub
		return new ProfEncadrant(new BasicPersonne(nom, prenom), univ, nombre);
	}

	public EncadrantStage getInstance(String nom,String prenom ,int i) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param basicPersonne
	 * @return
	 */
	



}
