package test;

import java.util.LinkedList;

import org.junit.*;

import ma.sqli.Decorator.BasicPersonne;
import ma.sqli.Decorator.*;
import ma.sqli.Decorator.ProfEncadrant;
import ma.sqli.FactoryPersone.FactoryPersone;
import ma.sqli.Mitier.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> ma
 * Package =====> test
 * Date    =====> 29 oct. 2019 
 */
public class Tests {
    private   Mitier  Gestion ;

	@Before
	public void initialiseData() {
		Gestion = new Mitier();
		FactoryPersone facp = new FactoryPersone();


		 
	
	} 
	//on va assure que on ne peut pas ajouter le meme etudiant deux foie
        @Test
        public void tester_si_on_peut_ajouter_un_etudiant_deux_foie() {
        	Gestion.ajoutEtudiant("mehdi", "bachir");
			Assert.assertEquals(false, Gestion.ajoutEtudiant("mehdi", "bachir"));

        }
        
      //on va assure que on ne peut pas ajouter le meme professeur  deux foie
        @Test
        public void tester_si_on_peut_ajouter_un_prof_deux_foie() {
        	Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4);			
        	Assert.assertEquals(false, Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4));

        }
		@Test
		public  void Tester_linsertion_des_etudiant() {
			Assert.assertEquals(true, Gestion.ajoutEtudiant("mehdi", "bachir"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("reda", "dhimni"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("annas", "ariss"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("Ayman", "bourhil"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("Hamza ", "sabair"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("Hassna", "belaini"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("Ihsanne", "Lachhab"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("Amine", "Aouni"));
			Assert.assertEquals(true, Gestion.ajoutEtudiant("simo", "Gnawi"));  
		}
		
		@Test
		public void Testet_linsertion_des_profs() {
			Assert.assertEquals(true, Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4));
			Assert.assertEquals(true, Gestion.ajoutProf("haziti", "haziti", "Mohamed5", 2));
			Assert.assertEquals(true, Gestion.ajoutProf("ourdi", "ourdi", "Mohamed5", 3));
			Assert.assertEquals(true, Gestion.ajoutProf("khatabi", "khatabi", "Mohamed5", 5));
			Assert.assertEquals(true, Gestion.ajoutProf("oumari", "oumari", "Mohamed5", 2));
			Assert.assertEquals(true, Gestion.ajoutProf("Benkhalifa", "BenKhalifa", "Mohamed5", 4));

       
		
		}
	   

	   @Test
	   public void  Tester_si_les_etudiants_ont_bien_recu_les_3_choix_des_prof() {
			FactoryPersone facp = new FactoryPersone();
            Etudiant e1,e2;
		    e1 = facp.getInstance("mehdi"," Bachir");
		    e2 = facp.getInstance("reda"," dhimni");
		    Gestion.addEtudiant(e1);
		    Gestion.addEtudiant(e2);
		    Gestion.ajoutProf("haziti", "haziti", "Mohamed5", 2);
		    Gestion.ajoutProf("ourdi", "ourdi", "Mohamed5", 3);
		    Gestion.ajoutProf("oumari", "oumari", "Mohamed5", 2);
		    Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4);
		    Gestion.ProfAleatoire();
		    
		    Assert.assertEquals(true, Gestion.choixDisponible(e1));
		    Assert.assertEquals(true, Gestion.choixDisponible(e2));
		 
	   }
	
		@Test
		public void  Tester_Les_choix_des_etudiants() {			
			FactoryPersone facp = new FactoryPersone();
            Etudiant e1,e2;
            ProfEncadrant p2;
            p2= facp.getInstance("ourdi", "ourdi", "Mohamed5", 3);
		    e1 = facp.getInstance("mehdi"," Bachir");
		    e2 = facp.getInstance("reda"," dhimni");
		    Gestion.addEtudiant(e1);
		    Gestion.addEtudiant(e2);
		    Gestion.ajoutProf("haziti", "haziti", "Mohamed5", 2);
		    Gestion.ajoutProf("ourdi", "ourdi", "Mohamed5", 3);
		    Gestion.ajoutProf("oumari", "oumari", "Mohamed5", 2);
		    Gestion.ajoutProf("Mohammed", "Bohdadi", "Mohamed5", 4);
		    Gestion.ProfAleatoire();
//            Gestion.choixPourChaqueEtudiant();	
//            Gestion.printEtudiants();
//            Assert.assertEquals(true, Gestion.testerChoix(e1, p2));
//            Assert.assertEquals(true, Gestion.testerChoix(e2, p2));
//          
            
			}

}
